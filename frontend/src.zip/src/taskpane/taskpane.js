/*
 * Google Drive集成插件 - 前端代码
 */

/* global document, Office, Word */

// 后端API基础URL
const API_BASE_URL = 'https://localhost:5001';

// 当前文件夹路径记录
let currentFolderPath = [{id: 'root', name: '根目录'}];
let tokenInfo = null;

// 当Office.js加载完成时执行初始化
Office.onReady((info) => {
  if (info.host === Office.HostType.Word) {
    console.log("Office已加载完成");
    
    // 初始化UI事件监听
    document.getElementById('login-button').onclick = function() {
      saveLoginState();
      startAuth();
    };
    
    document.getElementById('logout-button').onclick = handleSignoutClick;
    
    document.getElementById('search-button').onclick = searchFiles;
    
    document.getElementById('search-input').addEventListener('keypress', function(e) {
      if (e.key === 'Enter') {
        searchFiles();
      }
    });
    
    // 设置相关事件
    document.getElementById('settings-button').onclick = showSettings;
    document.getElementById('back-button').onclick = hideSettings;
    document.getElementById('save-settings').onclick = saveSettings;
    
    // 加载保存的设置
    loadSettings();
    
    // 检查URL中是否存在授权码
    const urlParams = new URLSearchParams(window.location.search);
    const code = urlParams.get('code');
    const state = urlParams.get('state');
    
    if (code && state) {
      // 处理授权回调
      handleAuthCallback(code, state);
    } else {
      // 检查是否有保存的令牌信息
      const savedToken = localStorage.getItem('tokenInfo');
      if (savedToken) {
        try {
          tokenInfo = JSON.parse(savedToken);
          // 检查令牌是否过期（简单检查，实际应检查expiry字段）
          if (tokenInfo && tokenInfo.token) {
            updateSigninStatus(true);
          }
        } catch (e) {
          console.error("解析保存的令牌时出错:", e);
          localStorage.removeItem('tokenInfo');
        }
      }
      
      // 检查是否需要自动登录
      checkAutoLogin();
    }
  }
});

// 开始授权流程
function startAuth() {
  console.log("开始授权流程");
  showLoading();
  
  fetch(`${API_BASE_URL}/api/get-auth-url`)
    .then(response => {
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      return response.json();
    })
    .then(data => {
      console.log("获取到授权URL");
      // 保存state以供验证
      localStorage.setItem('auth_state', data.state);
      
      // 重定向到Google授权页面
      window.location.href = data.auth_url;
    })
    .catch(error => {
      hideLoading();
      console.error("获取授权URL失败:", error);
      handleApiError({message: '启动授权过程时出错: ' + error.message});
    });
}

// 处理授权回调
function handleAuthCallback(code, state) {
  console.log("处理授权回调");
  showLoading();
  
  // 验证state以防CSRF攻击
  const savedState = localStorage.getItem('auth_state');
  if (state !== savedState) {
    hideLoading();
    handleApiError({message: '安全验证失败，请重试'});
    return;
  }
  
  // 交换授权码获取令牌
  fetch(`${API_BASE_URL}/api/auth-callback`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({code, state})
  })
    .then(response => {
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      return response.json();
    })
    .then(data => {
      hideLoading();
      
      // 保存令牌信息
      tokenInfo = data;
      localStorage.setItem('tokenInfo', JSON.stringify(tokenInfo));
      
      // 更新UI显示已登录状态
      updateSigninStatus(true);
      
      // 清除URL参数
      window.history.replaceState({}, document.title, window.location.pathname);
    })
    .catch(error => {
      hideLoading();
      console.error("处理授权回调失败:", error);
      handleApiError({message: '完成授权过程时出错: ' + error.message});
    });
}

// 处理登出
function handleSignoutClick() {
  console.log("开始处理登出");
  
  // 清除令牌信息
  tokenInfo = null;
  localStorage.removeItem('tokenInfo');
  
  // 更新UI显示未登录状态
  updateSigninStatus(false);
}

// 更新登录状态UI
function updateSigninStatus(isSignedIn) {
  console.log("更新登录状态:", isSignedIn);
  hideLoading();
  
  if (isSignedIn) {
    // 用户已登录，显示文件列表
    document.getElementById('login-section').style.display = 'none';
    document.getElementById('files-section').style.display = 'block';
    document.getElementById('settings-section').style.display = 'none';
    
    // 更新用户信息
    if (tokenInfo && tokenInfo.user_info) {
      const user = tokenInfo.user_info;
      document.getElementById('user-name').textContent = user.displayName || '用户';
      
      if (user.photoLink) {
        document.getElementById('user-photo').src = user.photoLink;
      }
    }
    
    // 加载根目录文件和文件夹
    listFolderContents('root');
    
    // 更新面包屑导航
    updateBreadcrumb();
  } else {
    // 用户未登录，显示登录界面
    document.getElementById('login-section').style.display = 'block';
    document.getElementById('files-section').style.display = 'none';
    document.getElementById('settings-section').style.display = 'none';
    
    // 清空当前路径
    currentFolderPath = [{id: 'root', name: '根目录'}];
  }
}

// 列出文件夹内容（分别请求文件夹和文件）
function listFolderContents(folderId) {
  console.log("列出文件夹内容:", folderId);
  showLoading();
  
  // 获取当前设置
  const sortBy = localStorage.getItem('sortSetting') || 'name';
  
  // 首先获取文件夹
  fetch(`${API_BASE_URL}/api/list-folders`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      ...tokenInfo,
      folder_id: folderId,
      sort_by: sortBy
    })
  })
    .then(response => {
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      return response.json();
    })
    .then(folderData => {
      // 然后获取文件
      return fetch(`${API_BASE_URL}/api/list-files`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          ...tokenInfo,
          folder_id: folderId,
          sort_by: sortBy
        })
      })
        .then(response => {
          if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
          }
          return response.json();
        })
        .then(fileData => {
          hideLoading();
          
          // 渲染文件夹和文件
          renderFolders(folderData.files || []);
          renderFiles(fileData.files || []);
        });
    })
    .catch(error => {
      hideLoading();
      console.error("列出文件夹内容失败:", error);
      handleApiError({message: '获取文件列表时出错: ' + error.message});
    });
}

// 渲染文件夹列表
function renderFolders(folders) {
  console.log("渲染文件夹:", folders.length);
  const foldersContainer = document.getElementById('folders-container');
  foldersContainer.innerHTML = '';
  
  if (folders.length === 0) {
    const emptyMessage = document.createElement('div');
    emptyMessage.className = 'empty-message';
    emptyMessage.textContent = '没有文件夹';
    foldersContainer.appendChild(emptyMessage);
    return;
  }
  
  folders.forEach(folder => {
    const folderDiv = document.createElement('div');
    folderDiv.className = 'folder-item';
    folderDiv.innerHTML = `
      <span class="folder-icon">📁</span>
      <span class="folder-name">${folder.name}</span>
    `;
    folderDiv.onclick = function() {
      // 更新当前路径
      currentFolderPath.push({id: folder.id, name: folder.name});
      
      // 列出新文件夹内容
      listFolderContents(folder.id);
      
      // 更新面包屑导航
      updateBreadcrumb();
    };
    foldersContainer.appendChild(folderDiv);
  });
}

// 渲染文件列表
function renderFiles(files) {
  console.log("渲染文件:", files.length);
  const filesContainer = document.getElementById('files-container');
  filesContainer.innerHTML = '';
  
  if (files.length === 0) {
    const emptyMessage = document.createElement('div');
    emptyMessage.className = 'empty-message';
    emptyMessage.textContent = '没有文件';
    filesContainer.appendChild(emptyMessage);
    return;
  }
  
  files.forEach(file => {
    const fileDiv = document.createElement('div');
    fileDiv.className = 'file-item';
    
    // 根据文件类型选择图标
    let fileIcon = '📄';
    if (file.mimeType === 'application/vnd.google-apps.document') {
      fileIcon = '📝';
    } else if (file.mimeType === 'application/vnd.google-apps.spreadsheet') {
      fileIcon = '📊';
    } else if (file.mimeType === 'application/vnd.google-apps.presentation') {
      fileIcon = '📑';
    } else if (file.mimeType.startsWith('image/')) {
      fileIcon = '🖼️';
    }
    
    fileDiv.innerHTML = `
      <span class="file-icon">${fileIcon}</span>
      <span class="file-name">${file.name}</span>
    `;
    
    // 点击文件预览
    fileDiv.onclick = function() {
      // 检查设置是否开启自动预览
      const autoPreview = localStorage.getItem('previewSetting') !== 'false';
      if (autoPreview) {
        previewFile(file);
      }
    };
    
    filesContainer.appendChild(fileDiv);
  });
}
// 预览文件
function previewFile(file) {
  console.log("预览文件:", file.name);
  const previewContainer = document.getElementById('preview-container');
  previewContainer.innerHTML = '';
  
  const fileInfo = document.createElement('div');
  fileInfo.className = 'file-info';
  
  // 确定文件类型和对应操作
  let fileTypeText = '文件';
  let canCopy = false;
  
  if (file.mimeType === 'application/vnd.google-apps.document') {
    fileTypeText = 'Google文档';
    canCopy = true;
  } else if (file.mimeType === 'application/vnd.google-apps.spreadsheet') {
    fileTypeText = 'Google表格';
  } else if (file.mimeType === 'application/vnd.google-apps.presentation') {
    fileTypeText = 'Google幻灯片';
  }
  
  fileInfo.innerHTML = `
    <h3>${file.name}</h3>
    <div>类型: ${fileTypeText}</div>
    <div class="file-actions">
      <button id="open-file" class="ms-Button">
        <span class="ms-Button-label">在Google中打开</span>
      </button>
      ${canCopy ? `
        <button id="copy-content" class="ms-Button ms-Button--primary">
          <span class="ms-Button-label">复制到Word</span>
        </button>
      ` : ''}
    </div>
  `;
  previewContainer.appendChild(fileInfo);
  
  // 绑定打开文件按钮
  document.getElementById('open-file').onclick = function() {
    window.open(file.webViewLink, '_blank');
  };
  
  // 绑定复制内容按钮（如果可用）
  if (canCopy) {
    document.getElementById('copy-content').onclick = function() {
      copyGoogleDocToWord(file.id);
    };
  }
}

// 从Google文档导出并复制到Word
function copyGoogleDocToWord(fileId) {
  console.log("导出Google文档:", fileId);
  showLoading();
  
  fetch(`${API_BASE_URL}/api/export-document`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      ...tokenInfo,
      file_id: fileId
    })
  })
    .then(response => {
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      return response.json();
    })
    .then(data => {
      const htmlContent = data.content;
      insertHtmlToWord(htmlContent);
    })
    .catch(error => {
      hideLoading();
      console.error("导出Google文档失败:", error);
      handleApiError({message: '导出文档时出错: ' + error.message});
    });
}

// 将HTML内容插入到Word
function insertHtmlToWord(htmlContent) {
  console.log("插入HTML到Word");
  
  Word.run(function(context) {
    context.document.body.insertHtml(htmlContent, Word.InsertLocation.end);
    return context.sync();
  }).then(function() {
    hideLoading();
    console.log("内容插入成功");
    
    // 显示成功消息
    const successMessage = document.createElement('div');
    successMessage.className = 'success-message';
    successMessage.textContent = '内容已成功复制到Word文档';
    document.body.appendChild(successMessage);
    
    // 5秒后自动移除成功信息
    setTimeout(() => {
      successMessage.remove();
    }, 5000);
    
  }).catch(function(error) {
    hideLoading();
    console.error("插入内容失败:", error);
    handleApiError({message: '插入内容时出错：' + (error.message || '未知错误')});
  });
}

// 搜索文件
function searchFiles() {
  const searchTerm = document.getElementById('search-input').value;
  if (!searchTerm) return;
  
  console.log("搜索文件:", searchTerm);
  showLoading();
  
  fetch(`${API_BASE_URL}/api/search-files`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      ...tokenInfo,
      search_term: searchTerm
    })
  })
    .then(response => {
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      return response.json();
    })
    .then(data => {
      hideLoading();
      console.log("搜索结果:", data.files.length);
      
      // 清空并显示搜索结果
      document.getElementById('folders-container').innerHTML = '<div class="search-heading">搜索结果</div>';
      renderFiles(data.files || []);
      
      // 更新面包屑导航，添加搜索指示器
      const breadcrumbContainer = document.getElementById('breadcrumb-container');
      breadcrumbContainer.innerHTML = `
        <span class="breadcrumb-item" data-id="root">根目录</span>
        <span class="breadcrumb-item">搜索: "${searchTerm}"</span>
      `;
      
      // 第一个面包屑项点击回到根目录
      breadcrumbContainer.querySelector('.breadcrumb-item[data-id="root"]').onclick = function() {
        currentFolderPath = [{id: 'root', name: '根目录'}];
        listFolderContents('root');
        updateBreadcrumb();
      };
      
    })
    .catch(error => {
      hideLoading();
      console.error("搜索文件失败:", error);
      handleApiError({message: '搜索文件时出错: ' + error.message});
    });
}

// 更新面包屑导航
function updateBreadcrumb() {
  console.log("更新面包屑导航");
  const breadcrumbContainer = document.getElementById('breadcrumb-container');
  breadcrumbContainer.innerHTML = '';
  
  currentFolderPath.forEach((folder, index) => {
    const breadcrumbItem = document.createElement('span');
    breadcrumbItem.className = 'breadcrumb-item';
    breadcrumbItem.setAttribute('data-id', folder.id);
    breadcrumbItem.textContent = folder.name;
    
    // 为非最后一项添加点击事件
    if (index < currentFolderPath.length - 1) {
      breadcrumbItem.onclick = function() {
        // 裁剪路径到当前点击的位置
        currentFolderPath = currentFolderPath.slice(0, index + 1);
        listFolderContents(folder.id);
        updateBreadcrumb();
      };
    }
    
    breadcrumbContainer.appendChild(breadcrumbItem);
  });
}

// 显示设置界面
function showSettings() {
  console.log("显示设置界面");
  document.getElementById('files-section').style.display = 'none';
  document.getElementById('settings-section').style.display = 'block';
}

// 隐藏设置界面
function hideSettings() {
  console.log("隐藏设置界面");
  document.getElementById('settings-section').style.display = 'none';
  document.getElementById('files-section').style.display = 'block';
}

// 检查是否需要自动登录
function checkAutoLogin() {
  console.log("检查是否需要自动登录");
  const autoLogin = localStorage.getItem('autoLoginSetting') === 'true';
  if (autoLogin && !tokenInfo) {
    console.log("尝试自动登录");
    // 尝试自动登录
    setTimeout(() => {
      startAuth();
    }, 1000);
  }
}

// 保存登录状态
function saveLoginState() {
  console.log("保存登录状态");
  const rememberAccount = document.getElementById('remember-account').checked;
  localStorage.setItem('autoLoginSetting', rememberAccount ? 'true' : 'false');
}

// 加载设置
function loadSettings() {
  console.log("加载设置");
  // 加载自动登录设置
  const autoLogin = localStorage.getItem('autoLoginSetting') === 'true';
  document.getElementById('remember-account').checked = autoLogin;
  document.getElementById('auto-login-setting').checked = autoLogin;
  
  // 加载预览设置
  const autoPreview = localStorage.getItem('previewSetting') !== 'false';
  document.getElementById('preview-setting').checked = autoPreview;
  
  // 加载排序设置
  const sortBy = localStorage.getItem('sortSetting') || 'name';
  document.getElementById('sort-setting').value = sortBy;
}

// 保存设置
function saveSettings() {
  console.log("保存设置");
  // 保存自动登录设置
  const autoLogin = document.getElementById('auto-login-setting').checked;
  localStorage.setItem('autoLoginSetting', autoLogin ? 'true' : 'false');
  
  // 保存预览设置
  const autoPreview = document.getElementById('preview-setting').checked;
  localStorage.setItem('previewSetting', autoPreview ? 'true' : 'false');
  
  // 保存排序设置
  const sortBy = document.getElementById('sort-setting').value;
  localStorage.setItem('sortSetting', sortBy);
  
  // 返回文件浏览界面并显示成功消息
  hideSettings();
  
  const successMessage = document.createElement('div');
  successMessage.className = 'success-message';
  successMessage.textContent = '设置已保存';
  document.body.appendChild(successMessage);
  
  // 5秒后自动移除成功信息
  setTimeout(() => {
    successMessage.remove();
  }, 3000);
  
  // 重新加载当前文件夹内容以应用新设置
  listFolderContents(currentFolderPath[currentFolderPath.length - 1].id);
}

// 显示加载状态
function showLoading() {
  document.getElementById('loading-indicator').style.display = 'flex';
}

// 隐藏加载状态
function hideLoading() {
  document.getElementById('loading-indicator').style.display = 'none';
}

// API错误处理
function handleApiError(error) {
  console.error('API错误:', error);
  
  let errorMessage = '发生错误，请重试';
  if (error.result && error.result.error && error.result.error.message) {
    errorMessage = `错误: ${error.result.error.message}`;
  } else if (error.message) {
    errorMessage = `错误: ${error.message}`;
  }
  
  // 显示错误信息
  const errorDiv = document.createElement('div');
  errorDiv.className = 'error-message';
  errorDiv.textContent = errorMessage;
  
  document.body.appendChild(errorDiv);
  
  // 5秒后自动移除错误信息
  setTimeout(() => {
    errorDiv.remove();
  }, 5000);
  
  // 如果是认证错误，尝试重新登录
  if ((error.status === 401) || 
      (error.result && error.result.error && error.result.error.code === 401)) {
    handleSignoutClick();
  }
}